from django.contrib import admin
from .models import TeamMember, Contact


# Register your models here.
admin.site.register(TeamMember)
admin.site.register(Contact)
